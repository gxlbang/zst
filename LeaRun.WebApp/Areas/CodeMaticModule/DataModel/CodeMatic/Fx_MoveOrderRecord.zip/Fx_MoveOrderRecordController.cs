using LeaRun.Business;
using LeaRun.Entity;
using LeaRun.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LeaRun.WebApp.Areas.ProductModule.Controllers
{
    /// <summary>
    /// �鵰��¼ �鵰��¼������
    /// </summary>
    public class Fx_MoveOrderRecordController : PublicController<Fx_MoveOrderRecord>
    {
    }
}