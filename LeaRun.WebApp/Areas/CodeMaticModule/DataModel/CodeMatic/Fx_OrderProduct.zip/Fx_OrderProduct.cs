//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2017
// Software Developers @ Learun 2017
//=====================================================================================

using LeaRun.DataAccess.Attributes;
using LeaRun.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LeaRun.Entity
{
    /// <summary>
    /// Fx_OrderProduct
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.10.31 12:17</date>
    /// </author>
    /// </summary>
    [Description("Fx_OrderProduct")]
    [PrimaryKey("Number")]
    public class Fx_OrderProduct : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// Number
        /// </summary>
        /// <returns></returns>
        [DisplayName("Number")]
        public string Number { get; set; }
        /// <summary>
        /// OrderNumber
        /// </summary>
        /// <returns></returns>
        [DisplayName("OrderNumber")]
        public string OrderNumber { get; set; }
        /// <summary>
        /// Pro_Number
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Number")]
        public string Pro_Number { get; set; }
        /// <summary>
        /// Pro_Name
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Name")]
        public string Pro_Name { get; set; }
        /// <summary>
        /// Pro_Price
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Price")]
        public double? Pro_Price { get; set; }
        /// <summary>
        /// Pro_Num
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Num")]
        public int? Pro_Num { get; set; }
        /// <summary>
        /// Pro_Image
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Image")]
        public string Pro_Image { get; set; }
        /// <summary>
        /// Pro_Size
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Size")]
        public string Pro_Size { get; set; }
        /// <summary>
        /// Pro_Brand
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Brand")]
        public string Pro_Brand { get; set; }
        /// <summary>
        /// Pro_Fac
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Fac")]
        public string Pro_Fac { get; set; }
        /// <summary>
        /// Pro_Adr
        /// </summary>
        /// <returns></returns>
        [DisplayName("Pro_Adr")]
        public string Pro_Adr { get; set; }
        /// <summary>
        /// Remark
        /// </summary>
        /// <returns></returns>
        [DisplayName("Remark")]
        public string Remark { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.Number = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.Number = KeyValue;
                                            }
        #endregion
    }
}