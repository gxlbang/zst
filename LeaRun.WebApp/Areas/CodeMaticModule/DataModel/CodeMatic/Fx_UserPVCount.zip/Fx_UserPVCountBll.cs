//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2017
// Software Developers @ Learun 2017
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// Fx_UserPVCount
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.11.15 16:42</date>
    /// </author>
    /// </summary>
    public class Fx_UserPVCountBll : RepositoryFactory<Fx_UserPVCount>
    {
    }
}